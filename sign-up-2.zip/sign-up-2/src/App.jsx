/* eslint-disable no-unused-vars */
import { useState } from 'react'
import './App.css'
import './components/Signup.jsx'
import Signup from './components/Signup.jsx'

function App() {

  return (
    <>
      <Signup/>
    </>
  )
}

export default App
